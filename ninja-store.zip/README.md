NINJA STORE
===========
-----------
Ninja Store is a very simple Express.js app for you to hack around and uderstand Express better.

It is a good project to start learnig Express because if covers GET and POST requests, the Jade template engine, the Stylus CSS engine, and sessions. All of it while being a tiny project.

-----------
Created by Captain Hack Sparrow